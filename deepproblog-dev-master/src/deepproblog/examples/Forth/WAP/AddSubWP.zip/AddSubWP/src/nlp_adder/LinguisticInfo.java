package nlp_adder;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class LinguisticInfo {
	ArrayList<LinguisticStep> sentences;
	LinkedHashSet<String> entities;
	LinkedHashSet<String> owners;
}
