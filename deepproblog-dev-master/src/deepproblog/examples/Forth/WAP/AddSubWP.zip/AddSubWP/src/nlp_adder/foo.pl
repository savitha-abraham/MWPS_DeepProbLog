foo(a).
foo(b).
